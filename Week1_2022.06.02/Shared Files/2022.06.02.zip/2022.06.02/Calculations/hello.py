print("Hello and welcome to Python!")
