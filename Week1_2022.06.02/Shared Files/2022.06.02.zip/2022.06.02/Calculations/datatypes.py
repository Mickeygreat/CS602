''' show data types'''


print("Hello World", type("Hello, World!"))
print(15,            type(15))
print(3.0,           type (3.0))
print('c',           type('c'))
print( True,         type (True))

print(type('This is a string.') )
print(type("And so is this.") )
print(type("""and this.""") )
print(type('''and even this...''') )

print('''"Oh no", Goldilocks exclaimed, "Someone's sitting in my chair!"''')

# multiple line strings

print("""This message will span
several lines
of the text.""")

print("""
1 - Option One
2 - Option Two
3 - Option Three
""")

# commas separate values
print (4,000)


