'''Created on Aug 27, 2018
 Eval  function demo
'''
  
expresison = input("enter an expression and I will evaluate it: ")
#print(type(expression))
print (expresison, ' evaluates to ', eval(expresison))