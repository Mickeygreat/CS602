'''
Created on Aug 27, 2018 @author: TBABAIAN
Demo numeric operations
''' 
import math

expression = '13/3'
print (expression, ' = ', eval(expression))
expression = '13//3'
print (expression, ' = ', eval(expression))

expression = '13%3'
print (expression, ' = ', eval(expression))

expression = '2**3'
print (expression, ' = ', eval(expression))


