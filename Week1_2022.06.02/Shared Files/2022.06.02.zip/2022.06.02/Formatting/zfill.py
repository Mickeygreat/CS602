'''
Created on Jan 13, 2020
@author: ruded
'''
val = 7.540638
print(int(val))
print(round(val))
print(round(val,1))
print(round(val,2))

val = 5
print(str(val).zfill(2))
print(str(val).zfill(8))
print( str(12).zfill(2))

print (str(1.2).zfill(3))
print (str(1.2).zfill(4))
print (str(1.2).zfill(2))