'''
Created on Jan 13, 2020
@author: ruded
'''
'''Created on Aug 27, 2018 @author: TBABAIAN
Demonstrating comparison operators '''
print ('---comparison of numbers----------------------------')
i = 5; j =9;
print (i > j);
print(i == j);
print(i != j);
print ('---comparison of Strings----------------------------')
str1, str2 = 'ABC', 'Foo'
print (str1 < str2)
print ('abc'<'abcd')
print ('ABC' < 'abc')
print ('ABC' == 'abc'.upper())