fruit = 'banana'
length = len(fruit)
last = fruit[length-1]
print(last)
print (fruit[0])
