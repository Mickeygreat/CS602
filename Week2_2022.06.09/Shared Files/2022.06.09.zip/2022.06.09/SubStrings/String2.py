s = 'Monty Python'
print('>'+s[0:5]+'<')
print('>'+s[6:10]+'<')

