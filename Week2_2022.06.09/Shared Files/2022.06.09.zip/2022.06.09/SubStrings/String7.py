greeting = 'Hello, world!'
new_greeting = 'J' + greeting[1:]
print(new_greeting)

