# combining conditions with and / or

count = int(input("Enter the count: "))
theSum = int(input("Enter the sum: "))
if count > 0 and theSum // count > 10:
  print("average > 10")
else:
  print("count = 0 or average <= 10")

