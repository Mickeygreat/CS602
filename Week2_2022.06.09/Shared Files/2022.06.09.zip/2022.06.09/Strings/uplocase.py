"""Demo of upper and lower case methods"""

name = input("What's your name? ")
print(name)

city = input("Where are you from? ").upper()
print(city)

city = city.lower()
print(city)
city = city.upper()
print(city)
univ = "bentley university"
print(univ.capitalize())
print(univ.title())
print(univ.swapcase())


