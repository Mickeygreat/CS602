fruit = 'banana'
x=len(fruit)
print(x)

