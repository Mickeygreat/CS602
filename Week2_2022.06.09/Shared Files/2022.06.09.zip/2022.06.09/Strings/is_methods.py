"""
is methods
"""

s = input("enter a string: ")
print("isalpha:  \t ",s.isalpha())
print("isdecimal:\t", s.isdecimal())
print("isdigit:  \t", s.isdigit())
print("isnumeric:\t", s.isnumeric())
print("isupper:  \t", s.isupper())
print("islower:  \t", s.islower())
