i=1
while (i<=3):
    j=1
    while (j<=6):
        print (j,end="")
        j=j+1
    print("\n")
    i=i+1
