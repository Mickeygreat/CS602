sum = 0
for i in range(5):
     print (i)
     sum += 1

print("after the loop", i)  
