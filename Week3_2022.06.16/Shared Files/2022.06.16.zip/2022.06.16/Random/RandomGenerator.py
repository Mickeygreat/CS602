'''
Created on Sep 16, 2020

@author: ruded
'''
import random

number1 = random.randint(0,1)
number2 = random.randint(1,6)
number3 = (int)(random.random() * 5 + 1)

print(number1, number2, number3)